Citizen.CreateThread(function()
    while true do
        Wait(0)
        -- Rockstar'ın kendi HUD componentlerini gizle
        HideHudComponentThisFrame(3) -- Cash
        HideHudComponentThisFrame(4) -- MP Cash
        HideHudComponentThisFrame(7) -- Area name (büyük yazı)
        HideHudComponentThisFrame(9) -- Street name (sağ alttaki)
        HideHudComponentThisFrame(6) -- Vehicle name
        HideHudComponentThisFrame(8) -- Vehicle class
        HideHudComponentThisFrame(13) -- Cash changes
        HideHudComponentThisFrame(1) -- Wanted stars
    end
end)


