fx_version 'cerulean'
game 'gta5'

author 'EMRAD'
description 'Native HUD Kapatma Scripti'
version '1.0.0'

client_scripts {
    'hidehud.lua'
}
